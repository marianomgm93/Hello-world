package extra.dao;


public class LibroDao extends Dao{
    
}
