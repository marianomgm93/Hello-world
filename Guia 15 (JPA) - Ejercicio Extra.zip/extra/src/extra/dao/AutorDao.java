package extra.dao;

public class AutorDao extends Dao {
    
}
