
package extra.dao;

public class ClienteDao extends Dao {
    
}
