package extra.dao;

public class EditorialDao extends Dao {
    
}
