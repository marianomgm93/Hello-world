
package extra.dao;

import extra.models.Autor;
import extra.models.Cliente;
import extra.models.Editorial;
import extra.models.Libro;
import extra.models.Prestamo;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public abstract class Dao {
    protected EntityManagerFactory emf = Persistence.createEntityManagerFactory("extraPU");
    protected EntityManager em = emf.createEntityManager();
    
    public void abrirConexion(){
        if(!em.isOpen()){
            em = emf.createEntityManager();
        }
    }
    
    public void cerrarConexion(){
        if(em.isOpen()){
            em.close();
        }
    }
    
    public void crearRegistro(Object obj){
        abrirConexion();
        em.getTransaction().begin();
        em.persist(obj);
        em.getTransaction().commit();
        cerrarConexion();
    }
    
    public void actualizarRegistro(Object obj){
        abrirConexion();
        em.getTransaction().begin();
        em.merge(obj);
        em.getTransaction().commit();
        cerrarConexion();
    }
    
    public void eliminarRegistro(Object obj){
        abrirConexion();
        em.getTransaction().begin();
        em.merge(obj);
        em.getTransaction().commit();
        cerrarConexion();
    }
    
    public Object buscarPorId(Object obj){
        if(obj instanceof Libro){
            Libro libro = (Libro) em.createQuery("Select l from Libro l WHERE l.alta = 1").getSingleResult();
            return libro;
        }
        if(obj instanceof Autor){
            Autor autor = (Autor) em.createQuery("Select a from Autor a WHERE a.alta = 1").getSingleResult();
            return autor;
        }
        if(obj instanceof Cliente){
            Cliente cliente = (Cliente) em.createQuery("Select c from Cliente c WHERE c.alta = 1").getSingleResult();
            return cliente;
        }
        if(obj instanceof Editorial){
            Editorial editorial = (Editorial) em.createQuery("Select e from Editorial e WHERE e.alta = 1").getSingleResult();
            return editorial;
        }
        if(obj instanceof Prestamo){
            Prestamo prestamo = (Prestamo) em.createQuery("Select p from Prestamo p WHERE p.alta = 1").getSingleResult();
            return prestamo;
        }
        return null;
    }
    
    
    public List<?> obtenerRegistros(String clase){
        return em.createQuery("SELECT "+clase.substring(0,1).toLowerCase()+" FROM "+ clase+ " "+clase.substring(0,1).toLowerCase()+" WHERE "+ clase.substring(0,1).toLowerCase()+".alta = 1").getResultList();
    } // Ejemplo --->   Select l from Libro l Where l.alta = 1;
    
    public List<?> obtenerRegistrosFlor(String clase){
        return em.createQuery("SELECT f FROM "+ clase+ " f WHERE f.alta = 1").getResultList();
    } // Ejemplo --->   Select l from Libro l Where l.alta = 1;
}
