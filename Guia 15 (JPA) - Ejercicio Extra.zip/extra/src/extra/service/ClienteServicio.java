package extra.service;

import extra.dao.ClienteDao;
import extra.mismetodos.Metodos;
import extra.models.Cliente;
import java.util.Scanner;

public class ClienteServicio {
    
    private ClienteDao cd = new ClienteDao();
    
    public Cliente crearCliente(){
        Cliente cliente = new Cliente();
        cliente.setDocumento(Metodos.validarLong("documento", "cliente"));
        cliente.setNombre(Metodos.pedirString("nombre", "cliente"));
        cliente.setApellido(Metodos.pedirString("apellido", "cliente"));
        cliente.setTelefono(Metodos.pedirString("telefono", "cliente"));
        return cliente;
    }
    
    
}
