package extra.mismetodos;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Metodos {
    
    private static Scanner leer = new Scanner(System.in);
    
    public static Long validarLong(String dato, String clase){
        do {
            try{
                System.out.println("Ingrese "+ dato +" del " + clase+ ":");
                Long num = leer.nextLong();
                return num;
            }catch(InputMismatchException e){
                System.out.println("Solo se aceptan numeros");
            }
                
        } while (true);
    }
    
    
    public static Integer validarInteger(String dato, String clase){
        do {
            try{
                System.out.println("Ingrese "+ dato +" del " + clase+ ":");
                Integer num = leer.nextInt();
                return num;
            }catch(InputMismatchException e){
                System.out.println("Solo se aceptan numeros");
            }
                
        } while (true);
    }
    
    public static String pedirString(String dato, String clase){
        System.out.println("Ingrese "+ dato +" del " + clase+ ":");
        String num = leer.nextLine();
        return num;
    }
    
}
